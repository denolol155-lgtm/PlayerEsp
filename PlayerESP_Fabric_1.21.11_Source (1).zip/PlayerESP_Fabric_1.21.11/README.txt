PLAYER ESP — Fabric / Minecraft Java 1.21.11

Features
- Green outline boxes around other players
- Player names above their heads (see-through text)
- Toggle on/off with O (default ON)
- Client-side; no server installation required
- 96-block render distance limit

Build
1. Install JDK 21.
2. Open this folder in IntelliJ IDEA as a Gradle project, or install Gradle.
3. Run: gradle build
4. The mod JAR will be created in build/libs/.
5. Put that JAR into your Minecraft instance's mods folder. Fabric API must also be installed.

Notes
- This project targets Fabric Loader 0.18.1, Fabric API 0.141.1+1.21.11 and Minecraft 1.21.11.
- The outline uses Minecraft's standard line render layer and may be hidden by solid blocks depending on the active renderer/depth pass. Names use see-through text.
- Use only where client-side visual mods are permitted by the server rules.
