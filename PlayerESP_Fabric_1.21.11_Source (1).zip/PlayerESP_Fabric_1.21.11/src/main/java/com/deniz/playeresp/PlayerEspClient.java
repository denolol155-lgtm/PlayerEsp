package com.deniz.playeresp;

import com.mojang.blaze3d.vertex.PoseStack;
import net.fabricmc.api.ClientModInitializer;
import net.fabricmc.fabric.api.client.event.lifecycle.v1.ClientTickEvents;
import net.fabricmc.fabric.api.client.keybinding.v1.KeyBindingHelper;
import net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderEvents;
import net.minecraft.client.Camera;
import net.minecraft.client.KeyMapping;
import net.minecraft.client.Minecraft;
import net.minecraft.client.renderer.LevelRenderer;
import net.minecraft.client.renderer.LightTexture;
import net.minecraft.client.renderer.MultiBufferSource;
import net.minecraft.client.renderer.RenderType;
import net.minecraft.client.gui.Font;
import net.minecraft.core.BlockPos;
import net.minecraft.world.entity.player.Player;
import net.minecraft.world.phys.AABB;
import net.minecraft.world.phys.Vec3;
import net.minecraft.network.chat.Component;
import org.lwjgl.glfw.GLFW;

public final class PlayerEspClient implements ClientModInitializer {
    private static boolean enabled = true;
    private static KeyMapping toggleKey;

    @Override
    public void onInitializeClient() {
        toggleKey = KeyBindingHelper.registerKeyBinding(new KeyMapping(
                "key.playeresp.toggle",
                GLFW.GLFW_KEY_O,
                "category.playeresp"
        ));

        ClientTickEvents.END_CLIENT_TICK.register(client -> {
            while (toggleKey.consumeClick()) {
                enabled = !enabled;
                if (client.player != null) {
                    client.player.displayClientMessage(
                            Component.literal("Player ESP: " + (enabled ? "ON" : "OFF")), true);
                }
            }
        });

        WorldRenderEvents.BEFORE_DEBUG_RENDER.register(PlayerEspClient::renderEsp);
    }

    private static void renderEsp(net.fabricmc.fabric.api.client.rendering.v1.world.WorldRenderContext context) {
        Minecraft client = Minecraft.getInstance();
        if (!enabled || client.level == null || client.player == null) return;

        Camera camera = client.gameRenderer.getMainCamera();
        Vec3 cameraPos = camera.getPosition();
        PoseStack matrices = context.matrices();
        MultiBufferSource buffers = context.consumers();

        for (Player target : client.level.players()) {
            if (target == client.player || !target.isAlive() || target.isSpectator()) continue;

            // Keep the overlay local and lightweight: ignore players farther than 96 blocks.
            if (client.player.distanceToSqr(target) > 96.0 * 96.0) continue;

            AABB box = target.getBoundingBox().inflate(0.04)
                    .move(-cameraPos.x, -cameraPos.y, -cameraPos.z);

            matrices.pushPose();
            LevelRenderer.renderLineBox(
                    matrices,
                    buffers.getBuffer(RenderType.lines()),
                    box,
                    0.20f, 0.95f, 0.35f, 1.0f
            );
            matrices.popPose();

            // Billboarded, see-through name above the player's head.
            matrices.pushPose();
            matrices.translate(
                    target.getX() - cameraPos.x,
                    target.getY() + target.getBbHeight() + 0.35 - cameraPos.y,
                    target.getZ() - cameraPos.z
            );
            matrices.mulPose(camera.rotation());
            matrices.scale(-0.025f, -0.025f, 0.025f);

            String name = target.getName().getString();
            Font font = client.font;
            float x = -font.width(name) / 2.0f;
            font.drawInBatch(
                    name,
                    x,
                    0,
                    0xFFFFFFFF,
                    false,
                    matrices.last().pose(),
                    buffers,
                    Font.DisplayMode.SEE_THROUGH,
                    0,
                    LightTexture.FULL_BRIGHT
            );
            matrices.popPose();
        }
    }
}
